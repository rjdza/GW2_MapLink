from distutils.core import setup

setup(name='gw2lib',
      version='0.1',
      packages=['gw2lib'],
      description='Guild Wars 2 Mumble and Web APIs',
      author=u"Terrasque",
      url="https://github.com/TheTerrasque/gw2lib"
      )